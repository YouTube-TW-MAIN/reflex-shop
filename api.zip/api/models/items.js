const mongoose = require("mongoose");

const chatSchema = new mongoose.Schema({
  name: String,
  img: String,
  des: String,
  price: String,
  owner: String,
  slug: String,
  ownerName: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Item", chatSchema);