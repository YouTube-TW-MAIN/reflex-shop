console.clear();
const express = require("express");
const app = express();
const mongoose = require("mongoose");
const path = require("path");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const ejsMate = require("ejs-mate");
const itemMilGae = require("./models/items");
const getSlugValues = require("slug-generator-js");
const port = 1001;
const fs = require("fs");
const axios = require("axios");
const seed = require("random-bytes-seed");
var base64 = require("base-64");
require("dotenv").config();

app.engine("ejs", ejsMate);

app.set("views", path.join(__dirname, "views"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");

main().then(() => {});

async function main() {
  await mongoose.connect(process.env.DATABASE);
}

app.get("/", async (req, res) => {
  let allitems = await itemMilGae.find({});
  res.render("index", { items: allitems });
});

app.get("/research", async (req, res) => {
  const val = req.query;
  const product = await itemMilGae.find({ slug: val.item });
  res.render("research", {
    owner: val.contact,
    slug: val.item,
    product: product,
  });
});

const api = process.env.API;

const fetch = require('node-fetch');

app.get("/test11", async (req, res) => {
  try {
    const response = await fetch("https://api.pdfshift.io/v3/convert/pdf", {
      method: "POST",
      headers: {
        Authorization: "Basic " + Buffer.from(`api:${api}`).toString("base64"),
        "Content-type": "application/json",
      },
      body: JSON.stringify({
        source: "https://en.wikipedia.org/wiki/PDF",
      }),
    });

    if (!response.ok) {
      throw new Error(`API returned ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    res.send(data);
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: "Error converting URL to PDF" });
  }
});
app.get("/researchbyadmin", async (req, res) => {
  const val = req.query;
  const product = await itemMilGae.deleteOne({ id: val.id });
  const newVal = encodeURIComponent(val.new);
  const redirectUrl =
    val.url + (val.url.includes("?") ? "&new=" : "?") + newVal;
  res.redirect(redirectUrl);
});

app.get("/models/add", (req, res) => {
  res.render("add");
});

app.get("/test", async (req, res) => {
  const base64String = req.query.password;
  console.log(req.query.new.length);
  const decodedString = atob(base64String);
  if (decodedString == "WORKING") {
    if (req.query.new.length == 99) {
      let allitems = await itemMilGae.find({});
      let url = req.url;
      console.error(url);
      res.render("index1", { items: allitems, url: url });
    } else {
      res.json({ err: "error on line 768:32" });
    }
  } else {
    res.errored("ee");
  }
});

app.post("/models/addinfos", async (req, res) => {
  const info = req.body;
  const nameSlug = getSlugValues(info.name, { separate: "-" });
  const itemNEW = new itemMilGae({
    name: info.name,
    img: info.photourl,
    des: info.des,
    price: info.pricce,
    owner: info.cUrl,
    slug: nameSlug,
    ownerName: info.oName,
  });
  await itemNEW.save().then(() => {
    res.redirect("/");
  });
});

app.get("/admin", async (req, res) => {
  const password = req.query.password;
  if (password === "WORKING") {
    const encoded = base64.encode(password);
    var randomBytes = seed(password);
    res.redirect(`/test?password=${encoded}&new=${randomBytes(100)}`);
  } else {
    res.json({ status: "ON MAINTANCE" });
  }
});

app.listen(port, () => {
  console.log(`${port}`);
});
